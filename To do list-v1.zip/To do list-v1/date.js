module.exports.getDate=function(){
    let today=new Date();
    let options={
        weekday:"long",
        day:"numeric",
        month:"long"
    };
    return today.toLocaleDateString("es-CO",options);
};

function getDay(){
    let today=new Date();
    let options={
        weekday:"long",
    };
    let day=today.toLocaleDateString("es-CO",options);
    return day;
};

module.exports.getDay=getDay;//Con () se llama la función inmediatamente