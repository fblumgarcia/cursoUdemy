const express=require("express");
const bodyParser=require("body-parser");
const mongoose=require("mongoose");
const date=require(__dirname+"/date.js");


const app=express();
app.use(bodyParser.urlencoded({extended:true}));
app.use(express.static("public"));//Para usar archivos estaticos como imagenes, css 
app.set("view engine","ejs");
//"mongodb://localhost:27017/todolistDB" local
mongoose.connect("mongodb+srv://fblumgarcia:cronoalgea97@cluster0.x0mnr.mongodb.net/myFirstDatabase?retryWrites=true&w=majority/todolistDB");

const itemsSchema={
    name:{
        type:String,
        require:true
    }
};
const listSchema={
    name:String,
    items:[itemsSchema]
};
const List=mongoose.model("List",listSchema);

const Item=mongoose.model("Item",itemsSchema);
const task1=new Item({name:"Buy Food"});
const task2=new Item({name:"Cook Food"});
const task3=new Item({name:"Eat Food"});

/*Item.insertMany([task1,task2,task3],function(err){
    if(err){
        console.log(err)
    }else{
        console.log("Create")
    }
})*/



app.get("/",function(req,res){

    Item.find({},function(err,foundItems){
        if(foundItems.length==0){
            Item.insertMany([task1,task2,task3],function(err){
                if(err){
                    console.log(err)
                }else{
                    console.log("Create")
                }
            });
            res.redirect("/");
        }else{
            res.render("list",{listTitle:date.getDate(),newListItems:foundItems});/*Postea lo de ejs */
        };
    });    
});
app.post("/",function(req,res){
    const itemName=req.body.newItem;
    const listName=req.body.list;
    const item=new Item({
        name:itemName
    });
    if(listName==date.getDate()){
        item.save();
        res.redirect("/");
    }else{
        List.findOne({name:listName},function(err,foundList){
            foundList.items.push(item);
            foundList.save();
            res.redirect("/"+listName);
        });
    };
    
});
app.post("/delete",function(req,res){
    const checkedItemId=req.body.checkbox;
    const listName=req.body.listName;    
    if(listName==date.getDate()){
        Item.deleteOne({_id:checkedItemId},function(err){
            if(err){
                console.log(err);
            }else{
                res.redirect("/");
            }
        });
    }else{
        List.findOneAndUpdate({name:listName},{$pull:{items:{_id:checkedItemId}}},function(err,foundList){
            if(!err){
                res.redirect("/"+listName);
            }
        });
    }
   
});

app.get("/:customListName",function(req,res){
    const customListName=req.params.customListName;
    List.findOne({name:customListName},function(err,foundList){
        if(!err){
            if(!foundList){
                const list=new List({
                    name:customListName,
                    items:[]
                });
                list.save();
                res.redirect("/"+customListName)
            }else{
                res.render("list",{listTitle:foundList.name,newListItems:foundList.items})
            }
        }else{
            console.log(err);
        }
        
    })  
    
});
app.post("/work",function(req,res){
    let item=req.body.newItem;
    workItems.push(item);
    res.redirect("/work");/*se reenvia la info al get para usarse allí*/
});
app.get("/about",function(req,res){
    res.render("about");
})
app.listen(process.env.PORT||3000,function(){
    console.log("server running in port 3000")
})
